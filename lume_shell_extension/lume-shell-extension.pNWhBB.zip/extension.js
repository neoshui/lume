/* Lume Clipboard Bridge — runs inside GNOME Shell, not as a normal client. */
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import St from 'gi://St';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

const MAX_ENTRIES = 200;

export default class LumeClipboardBridge extends Extension {
    enable() {
        this._dataDir = GLib.build_filenamev([GLib.get_user_data_dir(), 'lume', 'shell_clipboard']);
        this._imagesDir = GLib.build_filenamev([this._dataDir, 'images']);
        // make_directory_with_parents() throws FILE_EXISTS on every later
        // enable.  An extension may be re-enabled repeatedly by GNOME, so
        // only create this persistent directory on its first run.
        const imagesDir = Gio.File.new_for_path(this._imagesDir);
        if (!imagesDir.query_exists(null))
            imagesDir.make_directory_with_parents(null);
        this._clipboard = St.Clipboard.get_default();
        // Use the Shell singleton rather than the legacy global variable so
        // this keeps working across recent GNOME Shell releases.
        this._selection = Shell.Global.get().get_display().get_selection();
        this._entries = this._loadHistory();
        this._signalId = this._selection.connect('owner-changed', (_selection, type) => {
            if (type === Meta.SelectionType.SELECTION_CLIPBOARD)
                this._capture();
        });
    }

    disable() {
        if (this._signalId)
            this._selection.disconnect(this._signalId);
        this._signalId = 0;
        this._clipboard = null;
        this._selection = null;
    }

    _historyFile() {
        return Gio.File.new_for_path(GLib.build_filenamev([this._dataDir, 'history.json']));
    }

    _loadHistory() {
        try {
            const [ok, bytes] = this._historyFile().load_contents(null);
            return ok ? JSON.parse(new TextDecoder().decode(bytes)) : [];
        } catch (_) {
            return [];
        }
    }

    _saveHistory() {
        const output = new TextEncoder().encode(JSON.stringify(this._entries));
        this._historyFile().replace_contents(output, null, false,
            Gio.FileCreateFlags.REPLACE_DESTINATION, null);
    }

    _hash(bytes) {
        return GLib.compute_checksum_for_bytes(
            GLib.ChecksumType.SHA256,
            new GLib.Bytes(bytes),
        );
    }

    _add(entry) {
        const last = this._entries.at(-1);
        if (last && last.content_type === entry.content_type &&
            ((entry.content_type === 'text' && last.text === entry.text) ||
             (entry.content_type === 'image' && last.image_hash === entry.image_hash)))
            return;
        this._entries.push(entry);
        this._entries = this._entries.slice(-MAX_ENTRIES);
        this._saveHistory();
    }

    _capture() {
        const type = St.ClipboardType.CLIPBOARD;
        const mimetypes = this._clipboard.get_mimetypes(type);
        if (mimetypes.includes('image/png')) {
            this._clipboard.get_content(type, 'image/png', (_clipboard, bytes) => {
                const data = bytes instanceof GLib.Bytes ? bytes.get_data() : bytes;
                if (!data?.length)
                    return;
                const hash = this._hash(data);
                const path = GLib.build_filenamev([this._imagesDir, `shell_${hash}.png`]);
                Gio.File.new_for_path(path).replace_contents(data, null, false,
                    Gio.FileCreateFlags.REPLACE_DESTINATION, null);
                this._add({id: `shell_${hash}_${Date.now()}`, content_type: 'image',
                    image_path: path, image_hash: hash, captured_at: new Date().toISOString()});
            });
            return;
        }
        this._clipboard.get_text(type, (_clipboard, text) => {
            const value = text?.trim();
            if (!value)
                return;
            const hash = this._hash(new TextEncoder().encode(value));
            this._add({id: `shell_${hash}_${Date.now()}`, content_type: 'text', text: value,
                captured_at: new Date().toISOString()});
        });
    }
}
